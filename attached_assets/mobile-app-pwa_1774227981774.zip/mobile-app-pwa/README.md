# NaviMED Patient Portal - Mobile PWA

A mobile-first Progressive Web App for the NaviMED patient portal.

## Overview

This is a patient-facing mobile app that connects to the NaviMED healthcare platform API. Patients can view their health records, appointments, prescriptions, lab results, messages, and bills.

## Features

- Login with email, password, and hospital selection
- Dashboard with quick access to all features
- Patient profile with medical information
- Appointments list with status indicators
- Prescriptions with dosage and refill information
- Lab results with priority levels
- Medical messaging with providers
- Bills and insurance claims

## Quick Start

```bash
cd mobile-app-pwa
npm install
npm run dev
```

Open http://localhost:3000

## Test Login

- Email: sarah.johnson@email.com
- Password: password123
- Hospital: SAINT PAUL

## API Connection

Connects to: https://app.navimedi.org/api

All authenticated requests include the JWT token from login.

## Build for Production

```bash
npm run build
```

The production build will be in the `dist/` folder.

## Technology Stack

- React 18 with TypeScript
- Vite (build tool)
- Wouter (routing)
- Tailwind CSS (styling)
- Lucide React (icons)
- date-fns (date formatting)
- vite-plugin-pwa (PWA support)

## PWA Features

- Offline support via service worker
- Add to home screen
- App manifest for standalone mode
- Adaptive icons for iOS and Android

## Project Structure

```
mobile-app-pwa/
├── src/
│   ├── lib/
│   │   ├── api.ts        # API client
│   │   └── auth.ts       # Authentication
│   ├── pages/
│   │   ├── Login.tsx
│   │   ├── Dashboard.tsx
│   │   ├── Profile.tsx
│   │   ├── Appointments.tsx
│   │   ├── Prescriptions.tsx
│   │   ├── LabResults.tsx
│   │   ├── Messages.tsx
│   │   └── Bills.tsx
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── index.html
├── package.json
├── vite.config.ts
└── tailwind.config.js
```

## Install on Phone

### iPhone/iPad
1. Open in Safari
2. Tap Share button
3. Select "Add to Home Screen"

### Android
1. Open in Chrome
2. Tap Menu → "Install App"

## Troubleshooting

**Login fails**: Verify API is accessible at https://app.navimedi.org/api

**White screen**: Check browser console for errors

**Token expired**: Log out and log in again

## License

Part of NaviMED Healthcare Platform

## Last Updated

January 2026
